"""
Document upload and indexing endpoint
"""
from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
import httpx
import asyncio
import os
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/documents", tags=["documents"])

# Service URLs from environment
EMBED_URL = os.getenv("EMBED_URL", "http://embedding-service:8006/embed")
VECTOR_UPSERT_URL = os.getenv("VECTOR_DB_URL", "http://vector-db:8005") + "/upsert"


class IngestResponse(BaseModel):
    """Response from document ingestion"""
    files: int
    chunks_indexed: int
    status: str = "success"


async def _read_file(file: UploadFile) -> str:
    """Read uploaded file content"""
    data = await file.read()
    # TODO: Add proper parser for PDF/DOCX (use pypdf, python-docx, etc.)
    # For now, handle text files and attempt UTF-8 decode
    try:
        return data.decode("utf-8", errors="ignore")
    except Exception as e:
        logger.warning(f"Failed to decode {file.filename}: {e}")
        return ""


def _chunk(text: str, size: int = 800, overlap: int = 120) -> list[str]:
    """
    Simple token-based chunking with overlap.
    
    Args:
        text: Input text to chunk
        size: Chunk size in tokens (words)
        overlap: Overlap between chunks in tokens
    
    Returns:
        List of text chunks
    """
    tokens = text.split()
    chunks = []
    i = 0
    
    while i < len(tokens):
        chunk = " ".join(tokens[i:i+size])
        if chunk.strip():
            chunks.append(chunk)
        i += (size - overlap)
    
    return chunks


@router.post("", response_model=IngestResponse)
async def upload_documents(
    files: list[UploadFile] = File(...),
    perms_tag: str = "public"  # TODO: Wire to real auth with Depends(get_perms_tag)
):
    """
    Upload and index documents into vector database.
    
    Flow:
    1. Read file content
    2. Chunk text (800 tokens, 120 overlap)
    3. Generate embeddings
    4. Upsert to vector DB with ACL metadata
    
    Args:
        files: List of uploaded files
        perms_tag: Permission tag for ACL (default: public)
    
    Returns:
        IngestResponse with file count and chunks indexed
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")
    
    total_chunks = 0
    processed_files = 0
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        for f in files:
            try:
                # 1. Read file
                text = await _read_file(f)
                if not text or len(text.strip()) < 50:
                    logger.warning(f"Skipping {f.filename}: empty or too short")
                    continue
                
                # 2. Chunk
                chunks = _chunk(text)
                if not chunks:
                    logger.warning(f"Skipping {f.filename}: no chunks generated")
                    continue
                
                logger.info(f"Processing {f.filename}: {len(chunks)} chunks")
                
                # 3. Embed
                embed_response = await client.post(
                    EMBED_URL,
                    json={"texts": chunks}
                )
                embed_response.raise_for_status()
                embeddings = embed_response.json()["embeddings"]
                
                # 4. Upsert with ACL metadata
                vectors = []
                for i, emb in enumerate(embeddings):
                    vectors.append({
                        "id": f"{f.filename}:chunk_{i}",
                        "values": emb,
                        "metadata": {
                            "doc_title": f.filename,
                            "source_uri": f"upload://{f.filename}",
                            "perms_tag": perms_tag,
                            "chunk_index": i,
                            "total_chunks": len(chunks),
                            "file_type": f.content_type or "text/plain"
                        },
                        "text": chunks[i]
                    })
                
                upsert_response = await client.post(
                    VECTOR_UPSERT_URL,
                    json={"vectors": vectors}
                )
                upsert_response.raise_for_status()
                
                total_chunks += len(embeddings)
                processed_files += 1
                logger.info(f"✅ Indexed {f.filename}: {len(embeddings)} chunks")
                
            except httpx.HTTPError as e:
                logger.error(f"HTTP error processing {f.filename}: {e}")
                raise HTTPException(
                    status_code=502,
                    detail=f"Failed to process {f.filename}: {str(e)}"
                )
            except Exception as e:
                logger.error(f"Error processing {f.filename}: {e}")
                # Continue with other files instead of failing entire batch
                continue
    
    if processed_files == 0:
        raise HTTPException(
            status_code=400,
            detail="No files could be processed"
        )
    
    return IngestResponse(
        files=processed_files,
        chunks_indexed=total_chunks,
        status="success"
    )


@router.get("")
async def list_documents():
    """
    List all indexed documents.
    
    TODO: Implement by querying vector DB for unique doc_title metadata
    """
    # Placeholder - would query vector DB for unique documents
    return {
        "documents": [],
        "total": 0,
        "message": "Document listing not yet implemented"
    }
